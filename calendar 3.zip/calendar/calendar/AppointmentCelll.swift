//
//  AppointmentCell.swift
//  Appt
//
//  Created by Agustin Mendoza Romo on 5/15/17.
//  Copyright © 2017 AgustinMendoza. All rights reserved.
//

import UIKit

class AppointmentCell: UITableViewCell {
  
  @IBOutlet weak var dateLabel: UILabel!
  @IBOutlet weak var nameLabel: UILabel!
  @IBOutlet weak var noteLabel: UILabel!
  
}

