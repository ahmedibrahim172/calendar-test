//
//  Constants.swift
//  DemoMVC
//
//  Created by Anuradha Sharma on 03/02/17.
//  Copyright © 2017 Anuradha Sharma. All rights reserved.
//

import Foundation

class Constants
{
    static let kBasrUrl = "https://maps.googleapis.com/maps/api/place/autocomplete/json?"
    static let kGooglePlacesAPIKey = "AIzaSyBNTFrf0CqZ-h4_GARYM3Nolqe6Cys5eK8"
}
