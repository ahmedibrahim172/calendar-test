

import Foundation

class Constants
{
    static let kBasrUrl = "https://maps.googleapis.com/maps/api/place/autocomplete/json?"
    static let kGooglePlacesAPIKey = "AIzaSyBNTFrf0CqZ-h4_GARYM3Nolqe6Cys5eK8"
}
