//
//  PatientAppointmentCell.swift
//  Appt
//
//  Created by Agustin Mendoza Romo on 10/2/17.
//  Copyright © 2017 AgustinMendoza. All rights reserved.
//

import UIKit

class PatientAppointmentCell: UITableViewCell {

  @IBOutlet weak var dateLabel: UILabel!
  @IBOutlet weak var hourLabel: UILabel!
  @IBOutlet weak var noteLabel: UILabel!
  

}
