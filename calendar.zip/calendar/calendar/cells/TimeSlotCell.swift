

import UIKit

class TimeSlotCell: UICollectionViewCell {
  
  @IBOutlet weak var timeLabel: UILabel!
  @IBOutlet var timeSlotView: UIView!
  
}
