

import UIKit

class ActivityCell: UITableViewCell {

  @IBOutlet weak var timeIntervalLabel: UILabel!
  @IBOutlet weak var activityLabel: UILabel!
  
}
