

import UIKit
import JTAppleCalendar

class CalendarDayCell: JTAppleCell {
  @IBOutlet weak var dateLabel: UILabel!
  @IBOutlet weak var selectedView: UIView!
  
}

