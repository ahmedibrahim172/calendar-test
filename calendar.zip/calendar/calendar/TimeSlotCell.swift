//
//  TimeSlotCell.swift
//  Appt
//
//  Created by Agustin Mendoza Romo on 8/8/17.
//  Copyright © 2017 AgustinMendoza. All rights reserved.
//

import UIKit

class TimeSlotCell: UICollectionViewCell {
  
  @IBOutlet weak var timeLabel: UILabel!
  @IBOutlet var timeSlotView: UIView!
  
}
