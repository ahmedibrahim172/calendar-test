

import Foundation
import CoreData

@objc(Appointment)
public class Appointment: NSManagedObject {

}
